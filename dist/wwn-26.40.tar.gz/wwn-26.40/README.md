# Wednesware Nitrogen

Easy, ultra-lightweight installer for Wednesware publications.

## Installation methods:

### From PyPI via pipx (recommended, global install, run with `n2`):
* `pipx install wwn`

### From AUR via an AUR helper (best for arch linux, endeavouros, manjaro or garuda linux users, global install, run with `n2`):
* `yay -S n2`
* You may alternatively also use `paru`, `pikaur`, or any other AUR helper to install Nitrogen from the AUR instead of `yay`.

### From PyPI via pip (virtual environment or global install, run with `n2`):
* `pip install wwn`
* Note: You may need to create a virtual environment for this method first on some machines. [Learn how to do this here.](https://docs.python.org/3/library/venv.html)

### From GitHub via terminal (local install, run with `python -m nitrogen.nitrogen`):
* `git clone https://github.com/Wednesware/Nitrogen.git nitrogen`

### From Github via browser (local install, run with `python -m nitrogen.nitrogen`):
* [Click here to install the latest Nitrogen release as a zip file](https://github.com/Wednesware/Nitrogen/releases/latest/download/nitrogen.zip) [or click here to browse releases](https://github.com/Wednesware/Nitrogen/releases).
* Unpack using `bsdtar -xf nitrogen.zip`

## Upgrade methods:

### From PyPI
* `pip install wwn --upgrade`

## Usage:

### 

* `n2 get <publication> [release (latest by default)] [get subdependencies? (y/n)]` - Download a Wednesware publication from GitHub.
  * Example usage: `n2 get magnesium 26.3 n` (installs Magnesium release 26.3 to `ww/mg26_3`. Will not install sub-dependencies.)
  * Example usage: `n2 get helium latest y` (installs Magnesium's latest release' to `ww/mg`. Will also install sub-dependencies.)
  * Tip: you can use the chemical symbol for all publications to get them faster. Example: `n2 get mg 26.3 n`
* `n2 rm <publication> [release (all by default)]` - Delete all releases or a specific release of a publication from the current directory.
  * Example usage: `n2 rm magnesium 26.3` (deletes `./magnesium26_3` and `./mg26_3` only if present)
  * Or: `n2 rm magnesium` (deletes all files in `.` matching `magnesium*` or `mg*`)
  * Tip: you can use chemical symbols here too.
*  `n2 getdep [path]` - Smart-install missing dependencies from a .nitrodep file.
  * Example usage: `n2 getdep helium` (installs all dependencies required by Helium)
*  `n2 forcegetdep [path]` - Smart-install all dependencies, regardless of whether they are already installed, from a .nitrodep file, including nested ones, forcing reinstallation of all dependencies.
* `n2 help` - Prints a formatted help message to the terminal.
