from . import entrypoint


entrypoint()